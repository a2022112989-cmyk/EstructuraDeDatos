#pragma once
#include "Shape.h"
class Triangulo: public Shape
{
public:
	Triangulo(void);
	~Triangulo(void);
	 int getAreaT() {
		 return ((width * height)/2);
	  }
};

