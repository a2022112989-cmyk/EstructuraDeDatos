// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Triangulo.h"
#include "conio.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
   Triangulo* Tri = new Triangulo();
   Rect.setWidth(5);
   Rect.setHeight(7);
   int width, height;
   cout << "ingrese la altura: ";
   cin >> width;
   cout << "ingrese la base: ";
   cin >> height;
   Tri->setWidth(width);
   Tri->setHeight(height);
   cout << "total del area del tringulo es: " << Tri->getAreaT();

   Triangulo* Tri2 = new Triangulo();
   cout << "ingrese la altura: ";
   cin >> width;
   cout << "ingrese la base: ";
   cin >> height;
   Tri2->setWidth(width);
   Tri2->setHeight(height);
   cout << "total del area del tringulo es: " << Tri2->getAreaT();

   // Muestra el �rea de un rectangulo
   cout << "Total area rectangulo: " << Rect.getArea() << endl;
   cout << "Total area triangulo: " << Tri->getAreaT() << endl;
   cout << "Total area triangulo2: " << Tri2->getAreaT() << endl;
   return 0;
}