#include "stdafx.h"
#include "Triangulo.h"
#include "Shape.h"

Triangulo::Triangulo(void)
{
}


Triangulo::~Triangulo(void)
{
}

